import { useState, useEffect, useRef } from 'react';
import { StreamSettings, StreamStatus } from '../types';

const DEFAULT_CONSTRAINTS = {
  low: {
    video: { width: 640, height: 360 },
    audio: true
  },
  medium: {
    video: { width: 1280, height: 720 },
    audio: true
  },
  high: {
    video: { width: 1920, height: 1080 },
    audio: true
  }
};

export const useMediaStream = () => {
  const [status, setStatus] = useState<StreamStatus>(StreamStatus.IDLE);
  const [settings, setSettings] = useState<StreamSettings>({
    audio: true,
    video: true,
    screen: false,
    quality: 'medium'
  });
  
  const [error, setError] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startStream = async () => {
    try {
      setStatus(StreamStatus.REQUESTING);
      setError(null);
      
      if (settings.screen) {
        streamRef.current = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: settings.audio
        });
      } else {
        const constraints = {
          ...DEFAULT_CONSTRAINTS[settings.quality],
          audio: settings.audio,
          video: settings.video ? DEFAULT_CONSTRAINTS[settings.quality].video : false
        };
        
        streamRef.current = await navigator.mediaDevices.getUserMedia(constraints);
      }
      
      setStatus(StreamStatus.STREAMING);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to access media devices');
      setStatus(StreamStatus.ERROR);
      console.error('Error accessing media devices:', err);
    }
  };

  const stopStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setStatus(StreamStatus.ENDED);
  };

  const toggleAudio = () => {
    if (streamRef.current) {
      const audioTracks = streamRef.current.getAudioTracks();
      if (audioTracks.length > 0) {
        const enabled = !audioTracks[0].enabled;
        audioTracks.forEach(track => {
          track.enabled = enabled;
        });
        setSettings(prev => ({ ...prev, audio: enabled }));
      }
    }
  };

  const toggleVideo = () => {
    if (streamRef.current) {
      const videoTracks = streamRef.current.getVideoTracks();
      if (videoTracks.length > 0) {
        const enabled = !videoTracks[0].enabled;
        videoTracks.forEach(track => {
          track.enabled = enabled;
        });
        setSettings(prev => ({ ...prev, video: enabled }));
      }
    }
  };

  const toggleScreenShare = async () => {
    try {
      if (settings.screen) {
        // Switch back to camera
        setSettings(prev => ({ ...prev, screen: false }));
        stopStream();
        await startStream();
      } else {
        // Switch to screen sharing
        stopStream();
        setSettings(prev => ({ ...prev, screen: true }));
        await startStream();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to toggle screen sharing');
      console.error('Error toggling screen share:', err);
    }
  };

  const changeQuality = async (quality: 'low' | 'medium' | 'high') => {
    setSettings(prev => ({ ...prev, quality }));
    if (status === StreamStatus.STREAMING) {
      stopStream();
      await startStream();
    }
  };

  useEffect(() => {
    return () => {
      stopStream();
    };
  }, []);

  return {
    stream: streamRef.current,
    status,
    settings,
    error,
    startStream,
    stopStream,
    toggleAudio,
    toggleVideo,
    toggleScreenShare,
    changeQuality
  };
};