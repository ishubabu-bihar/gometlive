import React from 'react';
import Header from './components/Header';
import LiveStream from './components/LiveStream';

function App() {
  return (
    <div className="flex flex-col h-screen bg-gray-900 text-white">
      <Header />
      <main className="flex-1 p-4 overflow-hidden">
        <div className="mx-auto max-w-6xl h-full">
          <LiveStream />
        </div>
      </main>
      <footer className="bg-gray-900 border-t border-gray-800 py-3 px-4 text-center text-gray-500 text-sm">
        <p>© 2025 StreamLive. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;