export interface StreamSettings {
  audio: boolean;
  video: boolean;
  screen: boolean;
  quality: 'low' | 'medium' | 'high';
}

export enum StreamStatus {
  IDLE = 'idle',
  REQUESTING = 'requesting',
  STREAMING = 'streaming',
  ERROR = 'error',
  ENDED = 'ended'
}

export interface ChatMessage {
  id: string;
  sender: string;
  message: string;
  timestamp: Date;
}