import React from 'react';
import { Camera, Mic, MicOff, Video, VideoOff, MonitorPlay, Share2, Copy, Settings } from 'lucide-react';
import { StreamSettings, StreamStatus } from '../types';

interface StreamControlsProps {
  status: StreamStatus;
  settings: StreamSettings;
  onStart: () => void;
  onStop: () => void;
  onToggleAudio: () => void;
  onToggleVideo: () => void;
  onToggleScreen: () => void;
  onChangeQuality: (quality: 'low' | 'medium' | 'high') => void;
  onCopyLink: () => void;
}

const StreamControls: React.FC<StreamControlsProps> = ({
  status,
  settings,
  onStart,
  onStop,
  onToggleAudio,
  onToggleVideo,
  onToggleScreen,
  onChangeQuality,
  onCopyLink
}) => {
  const isStreaming = status === StreamStatus.STREAMING;
  
  return (
    <div className="flex flex-col w-full">
      <div className="flex items-center justify-center space-x-4 mb-4">
        {!isStreaming ? (
          <button
            onClick={onStart}
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2 rounded-full flex items-center transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
          >
            <Camera className="mr-2 h-5 w-5" />
            Start Streaming
          </button>
        ) : (
          <button
            onClick={onStop}
            className="bg-red-600 hover:bg-red-700 text-white font-medium px-6 py-2 rounded-full flex items-center transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50"
          >
            <VideoOff className="mr-2 h-5 w-5" />
            Stop Streaming
          </button>
        )}
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2">
        <button
          onClick={onToggleAudio}
          disabled={!isStreaming}
          className={`flex flex-col items-center justify-center p-3 rounded-lg transition-all ${
            isStreaming
              ? settings.audio
                ? 'bg-gray-700 hover:bg-gray-600 text-white'
                : 'bg-red-900/50 hover:bg-red-900 text-red-400'
              : 'bg-gray-800 text-gray-500 cursor-not-allowed'
          }`}
        >
          {settings.audio ? (
            <Mic className="h-6 w-6 mb-1" />
          ) : (
            <MicOff className="h-6 w-6 mb-1" />
          )}
          <span className="text-xs">
            {settings.audio ? 'Mute' : 'Unmute'}
          </span>
        </button>
        
        <button
          onClick={onToggleVideo}
          disabled={!isStreaming}
          className={`flex flex-col items-center justify-center p-3 rounded-lg transition-all ${
            isStreaming
              ? settings.video
                ? 'bg-gray-700 hover:bg-gray-600 text-white'
                : 'bg-red-900/50 hover:bg-red-900 text-red-400'
              : 'bg-gray-800 text-gray-500 cursor-not-allowed'
          }`}
        >
          {settings.video ? (
            <Video className="h-6 w-6 mb-1" />
          ) : (
            <VideoOff className="h-6 w-6 mb-1" />
          )}
          <span className="text-xs">
            {settings.video ? 'Hide' : 'Show'}
          </span>
        </button>
        
        <button
          onClick={onToggleScreen}
          disabled={!isStreaming}
          className={`flex flex-col items-center justify-center p-3 rounded-lg transition-all ${
            isStreaming
              ? settings.screen
                ? 'bg-indigo-700 hover:bg-indigo-600 text-white'
                : 'bg-gray-700 hover:bg-gray-600 text-white'
              : 'bg-gray-800 text-gray-500 cursor-not-allowed'
          }`}
        >
          <MonitorPlay className="h-6 w-6 mb-1" />
          <span className="text-xs">
            {settings.screen ? 'Camera' : 'Screen'}
          </span>
        </button>
        
        <button
          onClick={onCopyLink}
          className="flex flex-col items-center justify-center p-3 rounded-lg bg-gray-700 hover:bg-gray-600 text-white transition-all"
        >
          <Share2 className="h-6 w-6 mb-1" />
          <span className="text-xs">Share</span>
        </button>
        
        <div className="flex flex-col items-center justify-center p-3 rounded-lg bg-gray-700 hover:bg-gray-600 text-white transition-all relative group">
          <Settings className="h-6 w-6 mb-1" />
          <span className="text-xs">Quality</span>
          
          <div className="absolute bottom-full mb-2 bg-gray-800 rounded-lg p-2 shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all w-40">
            <div className="flex flex-col space-y-2">
              <button
                onClick={() => onChangeQuality('low')}
                className={`text-left px-3 py-1 rounded-md ${
                  settings.quality === 'low' ? 'bg-blue-700 text-white' : 'hover:bg-gray-700'
                }`}
              >
                Low (360p)
              </button>
              <button
                onClick={() => onChangeQuality('medium')}
                className={`text-left px-3 py-1 rounded-md ${
                  settings.quality === 'medium' ? 'bg-blue-700 text-white' : 'hover:bg-gray-700'
                }`}
              >
                Medium (720p)
              </button>
              <button
                onClick={() => onChangeQuality('high')}
                className={`text-left px-3 py-1 rounded-md ${
                  settings.quality === 'high' ? 'bg-blue-700 text-white' : 'hover:bg-gray-700'
                }`}
              >
                High (1080p)
              </button>
            </div>
            <div className="absolute w-3 h-3 bg-gray-800 transform rotate-45 left-1/2 -ml-1.5 -bottom-1.5"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StreamControls;