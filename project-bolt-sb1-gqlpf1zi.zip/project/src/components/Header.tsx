import React from 'react';
import { Video, User, Settings, BadgeHelp as Help } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gray-900 px-4 py-3 flex items-center justify-between shadow-md">
      <div className="flex items-center">
        <Video className="h-8 w-8 text-blue-500 mr-2" />
        <h1 className="text-white text-xl font-bold">StreamLive</h1>
      </div>
      
      <nav className="hidden md:flex items-center space-x-6">
        <a href="#" className="text-gray-300 hover:text-white transition-colors">Home</a>
        <a href="#" className="text-gray-300 hover:text-white transition-colors">Discover</a>
        <a href="#" className="text-gray-300 hover:text-white transition-colors">Following</a>
        <a href="#" className="text-blue-500 font-medium">Go Live</a>
      </nav>
      
      <div className="flex items-center space-x-2">
        <button className="p-2 text-gray-400 hover:text-white rounded-full hover:bg-gray-800 transition-colors">
          <Help className="h-5 w-5" />
        </button>
        <button className="p-2 text-gray-400 hover:text-white rounded-full hover:bg-gray-800 transition-colors">
          <Settings className="h-5 w-5" />
        </button>
        <button className="p-1 bg-blue-600 rounded-full">
          <User className="h-6 w-6 text-white" />
        </button>
      </div>
    </header>
  );
};

export default Header;