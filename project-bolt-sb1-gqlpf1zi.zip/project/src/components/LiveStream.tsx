import React, { useState, useCallback } from 'react';
import VideoPlayer from './VideoPlayer';
import StreamControls from './StreamControls';
import Chat from './Chat';
import { useMediaStream } from '../hooks/useMediaStream';
import { ChatMessage, StreamStatus } from '../types';
import { v4 as uuidv4 } from 'uuid';

const LiveStream: React.FC = () => {
  const {
    stream,
    status,
    settings,
    error,
    startStream,
    stopStream,
    toggleAudio,
    toggleVideo,
    toggleScreenShare,
    changeQuality
  } = useMediaStream();

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'System',
      message: 'Welcome to the live stream! Chat with others here.',
      timestamp: new Date()
    }
  ]);

  const sendMessage = useCallback((message: string) => {
    const newMessage: ChatMessage = {
      id: uuidv4(),
      sender: 'You',
      message,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, newMessage]);
  }, []);

  const copyStreamLink = useCallback(() => {
    // In a real app, this would be a unique URL for the stream
    const dummyStreamUrl = `${window.location.origin}/live/${uuidv4().substring(0, 8)}`;
    navigator.clipboard.writeText(dummyStreamUrl)
      .then(() => {
        const newMessage: ChatMessage = {
          id: uuidv4(),
          sender: 'System',
          message: 'Stream link copied to clipboard!',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, newMessage]);
      })
      .catch(err => {
        console.error('Failed to copy: ', err);
      });
  }, []);

  return (
    <div className="h-full max-h-full w-full flex flex-col">
      <div className="flex-1 flex flex-col md:flex-row gap-4 min-h-0">
        <div className="flex-1 flex flex-col min-h-0">
          <div className="relative flex-1 min-h-0 mb-4 rounded-lg overflow-hidden shadow-lg">
            <VideoPlayer stream={stream} status={status} error={error} />
          </div>
          
          <div className="bg-gray-800 p-4 rounded-lg shadow-lg mb-4">
            <StreamControls
              status={status}
              settings={settings}
              onStart={startStream}
              onStop={stopStream}
              onToggleAudio={toggleAudio}
              onToggleVideo={toggleVideo}
              onToggleScreen={toggleScreenShare}
              onChangeQuality={changeQuality}
              onCopyLink={copyStreamLink}
            />
          </div>
        </div>
        
        <div className="w-full md:w-80 h-80 md:h-auto flex-shrink-0">
          <Chat messages={messages} onSendMessage={sendMessage} />
        </div>
      </div>
    </div>
  );
};

export default LiveStream;