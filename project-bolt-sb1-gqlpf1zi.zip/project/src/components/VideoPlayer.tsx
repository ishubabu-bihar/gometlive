import React, { useRef, useEffect } from 'react';
import { StreamStatus } from '../types';
import { Camera, CameraOff, AlertTriangle } from 'lucide-react';

interface VideoPlayerProps {
  stream: MediaStream | null;
  status: StreamStatus;
  error: string | null;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ stream, status, error }) => {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  if (error) {
    return (
      <div className="relative w-full h-full bg-gray-900 rounded-lg flex items-center justify-center">
        <div className="text-center p-6">
          <AlertTriangle className="h-16 w-16 mx-auto text-red-500 mb-4" />
          <h3 className="text-xl font-medium text-white mb-2">Camera Error</h3>
          <p className="text-gray-300">{error}</p>
        </div>
      </div>
    );
  }

  if (status === StreamStatus.IDLE || status === StreamStatus.ENDED) {
    return (
      <div className="relative w-full h-full bg-gray-900 rounded-lg flex items-center justify-center">
        <div className="text-center p-6">
          <CameraOff className="h-16 w-16 mx-auto text-gray-400 mb-4" />
          <h3 className="text-xl font-medium text-white mb-2">Not Streaming</h3>
          <p className="text-gray-300">Click the start button to begin streaming</p>
        </div>
      </div>
    );
  }

  if (status === StreamStatus.REQUESTING) {
    return (
      <div className="relative w-full h-full bg-gray-900 rounded-lg flex items-center justify-center">
        <div className="text-center p-6">
          <div className="mx-auto h-16 w-16 animate-pulse">
            <Camera className="h-16 w-16 text-blue-500" />
          </div>
          <h3 className="text-xl font-medium text-white mt-4">Accessing Camera...</h3>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full bg-gray-900 rounded-lg overflow-hidden">
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="w-full h-full object-cover"
      />
      {status === StreamStatus.STREAMING && (
        <div className="absolute top-4 right-4 bg-red-500 px-3 py-1 rounded-full flex items-center">
          <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></div>
          <span className="text-white text-sm font-medium">LIVE</span>
        </div>
      )}
    </div>
  );
};

export default VideoPlayer;